import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
/**
 * The test class SilkRoadTest.
 *
 * Sara Gonzalez-Lizeth
 * @version (a version number or a date)
 */
public class SilkRoadC2Test {
    private SilkRoad road;

    @Before
    public void setUp() {
        // Crea una ruta de 10 posiciones
        road = new SilkRoad(10);
        road.placeStore(2, 5);  //tienda con 5 tenges
        road.placeStore(5, 8);  //tienda con 8 tenges
        road.placeRobot(0);     //robot en la posición inicial
    }

    @Test
    public void testMoveRobotValid() {
        road.moveRobot(0, 2); // mueve al robot de 0 a 2
        assertTrue(road.ok());
        assertEquals(2, road.robots()[0][1]);  // nueva posición = 2
    }

    @Test
    public void testMoveRobotInvalid() {
        road.moveRobot(0, 20); // movimiento inválido, se sale de la ruta
        assertFalse(road.ok()); // deberia fallar aca
    }

    @Test
    public void testProfitCollection() {
        int initialProfit = road.profit();
        road.moveRobot(0, 2); // el robot llega a la tienda en posición 2
        assertTrue(road.profit() >= initialProfit);
    }

    @Test
    public void testEmptiedStoresCounter() {
        road.moveRobot(0, 2); // robot recoge de tienda en 2
        int[][] emptied = road.emptiedStores();
        assertEquals(2, emptied[0][0]); // ubicación de la tienda
        assertTrue(emptied[0][1] >= 1); // aca dice que fue desocupada al menos una vez
    }

    @Test
    public void testProfitPerMoveTracking() {
        road.moveRobot(0, 2); // primer movimiento
        road.moveRobot(2, 3); // segundo movimiento
        int[][] profits = road.profitPerMove();
        assertEquals(2, profits[0].length - 1); // debe haber 2 registros de ganancias
    }

    @Test
    public void testRemoveStore() {
        road.removeStore(5);
        int[][] stores = road.stores();
        boolean found = false;
        for (int[] s : stores) {
            if (s[0] == 5) found = true;
        }
        assertFalse(found);
    }
}
