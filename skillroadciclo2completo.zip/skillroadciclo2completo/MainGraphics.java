
/**
 * Write a description of class MainGraphics here.
 * 
 * Sara G - Lizeth Niviay 
 * @version (a version number or a date)
 */

public class MainGraphics {
    public static void start(SilkRoad game) {
        game.makeVisible();
        MainConsole.start(game);
    }
}